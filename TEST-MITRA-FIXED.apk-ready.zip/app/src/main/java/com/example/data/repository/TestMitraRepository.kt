package com.example.data.repository

import android.util.Log
import com.example.data.model.CreateQuestionRequest
import com.example.data.model.CreateResultRequest
import com.example.data.model.CreateTestRequest
import com.example.data.model.CreateUserRequest
import com.example.data.model.EnrichedResult
import com.example.data.model.QuestionItem
import com.example.data.model.ResultItem
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.local.SessionManager
import com.example.data.remote.SupabaseClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import retrofit2.Response
import java.io.IOException

sealed class Resource<out T> {
    data class Success<out T>(val data: T) : Resource<T>()
    data class Error(val message: String, val isNetworkError: Boolean = false) : Resource<Nothing>()
    object Loading : Resource<Nothing>()
}

class TestMitraRepository(
    private val clientProvider: SupabaseClientProvider,
    private val sessionManager: SessionManager
) {

    private fun extractErrorMessage(response: Response<*>): String {
        return try {
            val errorBody = response.errorBody()?.string()
            if (!errorBody.isNullOrBlank()) {
                val json = JSONObject(errorBody)
                val msg = json.optString("message", "")
                val hint = json.optString("hint", "")
                val details = json.optString("details", "")
                val parts = mutableListOf<String>()
                if (msg.isNotBlank()) parts.add(msg)
                if (hint.isNotBlank()) parts.add("Hint: $hint")
                if (details.isNotBlank()) parts.add(details)
                if (parts.isNotEmpty()) {
                    return "Supabase (${response.code()}): ${parts.joinToString(" - ")}"
                }
            }
            "Supabase (${response.code()}): ${response.message()}"
        } catch (_: Exception) {
            "Supabase error (${response.code()}): ${response.message()}"
        }
    }

    suspend fun checkConnection(): Resource<Boolean> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase credentials not configured. Please set URL & Anon Key.")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests(select = "id", order = "id.asc")
            if (response.isSuccessful) {
                Resource.Success(true)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection or unable to reach Supabase: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Connection error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    suspend fun login(mobileNumber: String, password: String): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase URL and API Key must be configured first.")
        }
        try {
            val api = clientProvider.getApiService()
            val cleanMobile = mobileNumber.trim()
            val response = api.getUserByMobile("eq.$cleanMobile")

            if (!response.isSuccessful) {
                val detailedError = extractErrorMessage(response)
                return@withContext Resource.Error(detailedError)
            }

            val users = response.body().orEmpty()
            if (users.isEmpty()) {
                return@withContext Resource.Error("મોબાઇલ નંબર મળ્યો નથી અથવા પાસવર્ડ ખોટો છે (User not found or invalid password)")
            }

            val matchedUser = users.firstOrNull {
                it.password?.trim() == password.trim()
            }

            if (matchedUser != null) {
                if (!matchedUser.isActive) {
                    return@withContext Resource.Error("આ account Admin દ્વારા બંધ કરવામાં આવ્યું છે. / This account is disabled.")
                }

                val localDeviceId = sessionManager.getDeviceId()
                val registeredDeviceId = matchedUser.deviceId?.trim()

                when {
                    registeredDeviceId.isNullOrBlank() -> {
                        val claim = api.updateUserDevice(
                            idFilter = "eq.${matchedUser.id}",
                            deviceFilter = "is.null",
                            device = mapOf("device_id" to localDeviceId)
                        )
                        if (claim.isSuccessful && !claim.body().isNullOrEmpty()) {
                            Resource.Success(claim.body()!!.first())
                        } else {
                            // A concurrent login may have claimed the account first.
                            val verify = api.getUserByMobile("eq.$cleanMobile")
                            val current = verify.body().orEmpty().firstOrNull { it.id == matchedUser.id }
                            if (current?.deviceId == localDeviceId) {
                                Resource.Success(current)
                            } else {
                                Resource.Error("આ account બીજા device પર પહેલેથી login છે. પહેલા device પરથી Logout કરો.")
                            }
                        }
                    }
                    registeredDeviceId == localDeviceId -> Resource.Success(matchedUser)
                    else -> Resource.Error("આ account બીજા device પર પહેલેથી login છે. પહેલા device પરથી Logout કરો.")
                }
            } else {
                Resource.Error("ખોટો પાસવર્ડ છે! (Invalid password)")
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Login failed: ${e.localizedMessage ?: "Unable to connect to Supabase"}")
        }
    }

    suspend fun getAllUsers(): Resource<List<User>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getAllUsers()
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load users: ${e.localizedMessage}")
        }
    }

    suspend fun releaseDevice(userId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) return@withContext Resource.Error("Supabase not configured")
        try {
            val api = clientProvider.getApiService()
            val response = api.updateUserDevice(
                idFilter = "eq.$userId",
                deviceFilter = "eq.${sessionManager.getDeviceId()}",
                device = mapOf("device_id" to null)
            )
            if (response.isSuccessful) Resource.Success(Unit)
            else Resource.Error(extractErrorMessage(response))
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to logout device: ${e.localizedMessage}")
        }
    }

    suspend fun getUserById(userId: Long): Resource<User?> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) return@withContext Resource.Error("Supabase not configured")
        try {
            val response = clientProvider.getApiService().getUserById("eq.$userId")
            if (response.isSuccessful) Resource.Success(response.body()?.firstOrNull())
            else Resource.Error(extractErrorMessage(response))
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to verify account: ${e.localizedMessage}")
        }
    }

    suspend fun registerUser(mobileNumber: String, password: String, role: String = "student"): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val cleanMobile = mobileNumber.trim()
            val cleanPassword = password.trim()
            val cleanRole = role.trim().lowercase()

            val api = clientProvider.getApiService()

            // Check if mobile already exists
            val checkResp = api.getUserByMobile("eq.$cleanMobile")
            if (checkResp.isSuccessful && !checkResp.body().isNullOrEmpty()) {
                return@withContext Resource.Error("આ મોબાઇલ નંબર પહેલેથી રજીસ્ટર છે! (Mobile number already exists)")
            }

            val req = CreateUserRequest(
                mobileNumber = cleanMobile,
                password = cleanPassword,
                role = cleanRole,
                isActive = true
            )
            val response = api.createUser(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: User(mobileNumber = cleanMobile, role = cleanRole)
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save student.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to add student: ${e.localizedMessage}")
        }
    }

    suspend fun deleteUser(userId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteUser("eq.$userId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete student: ${e.localizedMessage}")
        }
    }

    suspend fun getTests(): Resource<List<TestItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests()
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load tests: ${e.localizedMessage}")
        }
    }

    suspend fun getTestById(testId: Long): Resource<TestItem?> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) return@withContext Resource.Error("Supabase not configured")
        try {
            val response = clientProvider.getApiService().getTestById("eq.$testId")
            if (response.isSuccessful) Resource.Success(response.body()?.firstOrNull())
            else Resource.Error(extractErrorMessage(response))
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load test: ${e.localizedMessage}")
        }
    }

    suspend fun getQuestionsForTest(testId: Long): Resource<List<QuestionItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getQuestionsForTest("eq.$testId")
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load questions: ${e.localizedMessage}")
        }
    }

    suspend fun submitResult(userId: Long, testId: Long, score: Double): Resource<ResultItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val req = CreateResultRequest(userId = userId, testId = testId, score = score)
            val response = api.submitResult(req)
            if (response.isSuccessful) {
                val saved = response.body()?.firstOrNull() ?: ResultItem(userId = userId, testId = testId, score = score)
                Resource.Success(saved)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save result.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to save result: ${e.localizedMessage}")
        }
    }

    suspend fun getStudentResults(userId: Long): Resource<List<EnrichedResult>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val resultsResp = api.getResultsForUser("eq.$userId")
            val testsResp = api.getTests()

            if (resultsResp.isSuccessful && testsResp.isSuccessful) {
                val results = resultsResp.body().orEmpty()
                val testsMap = testsResp.body().orEmpty().associateBy { it.id ?: 0L }

                val enriched = results.map { res ->
                    val test = testsMap[res.testId]
                    EnrichedResult(
                        id = res.id,
                        userId = res.userId,
                        userMobile = "",
                        testId = res.testId,
                        testName = test?.testName ?: "Test #${res.testId}",
                        testDuration = test?.duration ?: 0,
                        score = res.score,
                        createdAt = res.createdAt
                    )
                }
                Resource.Success(enriched)
            } else {
                val err = if (!resultsResp.isSuccessful) extractErrorMessage(resultsResp) else extractErrorMessage(testsResp)
                Resource.Error(err)
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load results: ${e.localizedMessage}")
        }
    }

    suspend fun getAllResultsWithDetails(): Resource<List<EnrichedResult>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val resultsResp = api.getResults()
            val testsResp = api.getTests()
            val usersResp = api.getAllUsers()

            if (resultsResp.isSuccessful) {
                val results = resultsResp.body().orEmpty()
                val testsMap = testsResp.body().orEmpty().associateBy { it.id ?: 0L }
                val usersMap = usersResp.body().orEmpty().associateBy { it.id ?: 0L }

                val enriched = results.map { res ->
                    val test = testsMap[res.testId]
                    val user = usersMap[res.userId]
                    EnrichedResult(
                        id = res.id,
                        userId = res.userId,
                        userMobile = user?.mobileNumber ?: "User #${res.userId}",
                        testId = res.testId,
                        testName = test?.testName ?: "Test #${res.testId}",
                        testDuration = test?.duration ?: 0,
                        score = res.score,
                        createdAt = res.createdAt
                    )
                }
                Resource.Success(enriched)
            } else {
                Resource.Error(extractErrorMessage(resultsResp))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load results: ${e.localizedMessage}")
        }
    }

    suspend fun createTest(testName: String, durationMinutes: Int): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val req = CreateTestRequest(testName = testName.trim(), duration = durationMinutes, isActive = true)
            val response = api.createTest(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: TestItem(testName = testName.trim(), duration = durationMinutes, isActive = true)
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to create test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to create test: ${e.localizedMessage}")
        }
    }

    suspend fun setTestActive(testId: Long, active: Boolean): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) return@withContext Resource.Error("Supabase not configured")
        try {
            val response = clientProvider.getApiService().updateTestActive(
                idFilter = "eq.$testId",
                active = mapOf("is_active" to active)
            )
            if (response.isSuccessful) {
                response.body()?.firstOrNull()?.let { Resource.Success(it) }
                    ?: Resource.Error("Test status was not updated.")
            } else Resource.Error(extractErrorMessage(response))
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update test status: ${e.localizedMessage}")
        }
    }

    suspend fun deleteTest(testId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            // First delete associated questions
            try {
                api.deleteQuestion("eq.$testId")
            } catch (_: Exception) {}

            val response = api.deleteTest("eq.$testId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to delete test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete test: ${e.localizedMessage}")
        }
    }

    suspend fun addQuestion(
        testId: Long,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String
    ): Resource<QuestionItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val req = CreateQuestionRequest(
                testId = testId,
                questionText = questionText.trim(),
                optionA = optionA.trim(),
                optionB = optionB.trim(),
                optionC = optionC.trim(),
                optionD = optionD.trim(),
                correctOption = correctOption.trim().uppercase()
            )
            val response = api.createQuestion(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: QuestionItem(
                    testId = testId,
                    questionText = questionText.trim(),
                    optionA = optionA.trim(),
                    optionB = optionB.trim(),
                    optionC = optionC.trim(),
                    optionD = optionD.trim(),
                    correctOption = correctOption.trim().uppercase()
                )
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save question.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to save question: ${e.localizedMessage}")
        }
    }

    suspend fun deleteQuestion(questionId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteQuestion("eq.$questionId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete question: ${e.localizedMessage}")
        }
    }
}
