package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.example.data.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionManager(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getDeviceId(): String {
        return Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
            ?.takeIf { it.isNotBlank() }
            ?: "android-${android.os.Build.FINGERPRINT}"
    }

    private val _currentUser = MutableStateFlow(loadUser())
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _supabaseConfig = MutableStateFlow(loadSupabaseConfig())
    val supabaseConfig: StateFlow<Pair<String, String>> = _supabaseConfig.asStateFlow()

    fun saveUser(user: User) {
        prefs.edit().apply {
            putLong(KEY_USER_ID, user.id ?: -1L)
            putString(KEY_USER_MOBILE, user.mobileNumber)
            putString(KEY_USER_ROLE, user.role)
            putString(KEY_USER_DEVICE_ID, user.deviceId)
            putBoolean(KEY_USER_ACTIVE, user.isActive)
            apply()
        }
        _currentUser.value = user
    }

    fun clearSession() {
        prefs.edit().apply {
            remove(KEY_USER_ID)
            remove(KEY_USER_MOBILE)
            remove(KEY_USER_ROLE)
            remove(KEY_USER_DEVICE_ID)
            remove(KEY_USER_ACTIVE)
            apply()
        }
        _currentUser.value = null
    }

    fun getUser(): User? = _currentUser.value

    fun isLoggedIn(): Boolean = _currentUser.value != null

    fun saveSupabaseConfig(url: String, anonKey: String) {
        val cleanUrl = url.trim().trimEnd('/')
        val cleanKey = anonKey.trim()
        prefs.edit().apply {
            putString(KEY_SUPABASE_URL, cleanUrl)
            putString(KEY_SUPABASE_ANON_KEY, cleanKey)
            apply()
        }
        _supabaseConfig.value = Pair(cleanUrl, cleanKey)
    }

    fun getSupabaseConfig(): Pair<String, String> = _supabaseConfig.value

    private fun loadUser(): User? {
        val id = prefs.getLong(KEY_USER_ID, -1L)
        val mobile = prefs.getString(KEY_USER_MOBILE, null)
        val role = prefs.getString(KEY_USER_ROLE, "student") ?: "student"
        val deviceId = prefs.getString(KEY_USER_DEVICE_ID, null)
        val isActive = prefs.getBoolean(KEY_USER_ACTIVE, true)

        return if (mobile != null) {
            User(
                id = if (id >= 0) id else null,
                mobileNumber = mobile,
                password = null,
                role = role,
                deviceId = deviceId,
                isActive = isActive
            )
        } else {
            null
        }
    }

    private fun loadSupabaseConfig(): Pair<String, String> {
        val savedUrl = prefs.getString(KEY_SUPABASE_URL, DEFAULT_SUPABASE_URL) ?: DEFAULT_SUPABASE_URL
        val savedKey = prefs.getString(KEY_SUPABASE_ANON_KEY, DEFAULT_SUPABASE_ANON_KEY) ?: DEFAULT_SUPABASE_ANON_KEY
        return Pair(savedUrl.ifBlank { DEFAULT_SUPABASE_URL }, savedKey.ifBlank { DEFAULT_SUPABASE_ANON_KEY })
    }

    companion object {
        private const val PREFS_NAME = "test_mitra_session_prefs"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_MOBILE = "user_mobile"
        private const val KEY_USER_ROLE = "user_role"
        private const val KEY_USER_DEVICE_ID = "user_device_id"
        private const val KEY_USER_ACTIVE = "user_active"
        private const val KEY_SUPABASE_URL = "supabase_url"
        private const val KEY_SUPABASE_ANON_KEY = "supabase_anon_key"

        // Default Pre-Connected Supabase Project Credentials
        const val DEFAULT_SUPABASE_URL = "https://vyxcerbdrjjphhqoksup.supabase.co"
        const val DEFAULT_SUPABASE_ANON_KEY = "sb_publishable_kZ4HFanq__cSA5yrrhXT1w_yi9lchOL"
    }
}
