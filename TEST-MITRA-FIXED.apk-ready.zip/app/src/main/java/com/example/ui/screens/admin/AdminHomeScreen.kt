package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SessionManager
import com.example.data.model.QuestionItem
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraOutlinedButton
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.components.SupabaseConfigDialog
import com.example.ui.components.TestMitraTopBar
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraOrangeLight
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    user: User,
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var testsList by remember { mutableStateOf<List<TestItem>>(emptyList()) }
    var usersList by remember { mutableStateOf<List<User>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showConfigDialog by remember { mutableStateOf(false) }

    // Dialog state for viewing questions of a test
    var viewingQuestionsTest by remember { mutableStateOf<TestItem?>(null) }
    var testQuestionsList by remember { mutableStateOf<List<QuestionItem>>(emptyList()) }
    var isLoadingQuestions by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun loadAllData() {
        isLoading = true
        errorMessage = null
        scope.launch {
            val testsRes = repository.getTests()
            val usersRes = repository.getAllUsers()
            isLoading = false
            when {
                testsRes is Resource.Success -> {
                    testsList = testsRes.data
                    if (usersRes is Resource.Success) {
                        usersList = usersRes.data
                    }
                }
                testsRes is Resource.Error -> {
                    errorMessage = testsRes.message
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        loadAllData()
    }

    Scaffold(
        topBar = {
            TestMitraTopBar(
                title = "TEST MITRA",
                subtitle = "Teacher & Admin • ${user.mobileNumber}",
                userRole = "Teacher/Admin",
                onRefresh = { loadAllData() },
                onOpenSettings = { showConfigDialog = true },
                onLogout = {
                    scope.launch {
                        user.id?.let { repository.releaseDevice(it) }
                        sessionManager.clearSession()
                        onLogout()
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_home_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight)
        ) {
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = MitraNavyPrimary)
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Connecting to Supabase...\nડેટા મેળવી રહ્યા છીએ...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { loadAllData() },
                        onOpenSettings = { showConfigDialog = true }
                    )
                }

                else -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // 3 Navigation Tabs: Tests, Students, Create/Add
                        ScrollableTabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = Color.White,
                            contentColor = MitraNavyPrimary,
                            edgePadding = 8.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Tab(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                text = {
                                    Text(
                                        text = "Tests (${testsList.size})\nટેસ્ટ યાદી",
                                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_tests")
                            )
                            Tab(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                text = {
                                    Text(
                                        text = "Students (${usersList.count { !it.isTeacherOrAdmin }})\nસ્ટુડન્ટ્સ",
                                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_students")
                            )
                            Tab(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                text = {
                                    Text(
                                        text = "Create / Add\nનવું ઉમેરો",
                                        fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                },
                                modifier = Modifier.testTag("admin_tab_add")
                            )
                        }

                        // Tab 0: Tests Management
                        if (selectedTab == 0) {
                            if (testsList.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "No Tests Created Yet",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MitraTextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Go to 'Create / Add' tab to create your first test.",
                                            fontSize = 13.sp,
                                            color = MitraTextSecondary
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        MitraPrimaryButton(
                                            text = "Create Test Now / ટેસ્ટ બનાવો",
                                            onClick = { selectedTab = 2 }
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("admin_tests_list"),
                                    contentPadding = PaddingValues(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    items(testsList, key = { it.id ?: 0L }) { test ->
                                        AdminTestItemCard(
                                            test = test,
                                            onViewQuestions = {
                                                viewingQuestionsTest = test
                                                isLoadingQuestions = true
                                                scope.launch {
                                                    val qRes = repository.getQuestionsForTest(test.id ?: 0L)
                                                    isLoadingQuestions = false
                                                    if (qRes is Resource.Success) {
                                                        testQuestionsList = qRes.data
                                                    }
                                                }
                                            },
                                            onToggleActive = {
                                                scope.launch {
                                                    val statusRes = repository.setTestActive(test.id ?: 0L, !test.isActive)
                                                    if (statusRes is Resource.Success) {
                                                        snackbarHostState.showSnackbar(
                                                            if (!test.isActive) "Test activated / ટેસ્ટ ચાલુ કર્યો"
                                                            else "Test deactivated / ટેસ્ટ બંધ કર્યો"
                                                        )
                                                        loadAllData()
                                                    } else if (statusRes is Resource.Error) {
                                                        snackbarHostState.showSnackbar(statusRes.message)
                                                    }
                                                }
                                            },
                                            onDelete = {
                                                scope.launch {
                                                    val delRes = repository.deleteTest(test.id ?: 0L)
                                                    if (delRes is Resource.Success) {
                                                        snackbarHostState.showSnackbar("Test deleted successfully / ટેસ્ટ કાઢી નાખવામાં આવ્યો")
                                                        loadAllData()
                                                    } else if (delRes is Resource.Error) {
                                                        snackbarHostState.showSnackbar(delRes.message)
                                                    }
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Tab 1: Students Management
                        else if (selectedTab == 1) {
                            AdminStudentsSection(
                                usersList = usersList,
                                repository = repository,
                                onStudentAdded = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Student added successfully! / વિદ્યાર્થી સફળતાપૂર્વક ઉમેરાઈ ગયો!")
                                    }
                                },
                                onStudentDeleted = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Student removed! / વિદ્યાર્થી કાઢી નાખવામાં આવ્યો!")
                                    }
                                }
                            )
                        }

                        // Tab 2: Create Test & Add Question
                        else if (selectedTab == 2) {
                            AdminCreateContentSection(
                                testsList = testsList,
                                repository = repository,
                                onTestCreated = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Test created successfully! / નવો ટેસ્ટ ઉમેરાઈ ગયો!")
                                    }
                                },
                                onQuestionAdded = {
                                    loadAllData()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Question saved to Supabase! / પ્રશ્ન સાચવી લીધો!")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal: View & Manage Questions for a specific test
    if (viewingQuestionsTest != null) {
        val test = viewingQuestionsTest!!
        AlertDialog(
            onDismissRequest = { viewingQuestionsTest = null },
            modifier = Modifier.testTag("test_questions_modal"),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = test.testName,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                        Text(
                            text = "Questions in this test (${testQuestionsList.size})",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                }
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                ) {
                    if (isLoadingQuestions) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = MitraNavyPrimary)
                        }
                    } else if (testQuestionsList.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = "No questions added yet.\nGo to 'Create / Add' tab to add questions to this test.",
                                fontSize = 13.sp,
                                color = MitraTextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(testQuestionsList, key = { it.id ?: 0L }) { q ->
                                Card(
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                    border = BorderStroke(1.dp, MitraBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = q.questionText,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MitraTextPrimary,
                                                modifier = Modifier.weight(1f)
                                            )
                                            IconButton(
                                                onClick = {
                                                    scope.launch {
                                                        val delQRes = repository.deleteQuestion(q.id ?: 0L)
                                                        if (delQRes is Resource.Success) {
                                                            testQuestionsList = testQuestionsList.filter { it.id != q.id }
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete Question",
                                                    tint = MitraError,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = "A: ${q.optionA} | B: ${q.optionB}", fontSize = 11.sp, color = MitraTextSecondary)
                                        Text(text = "C: ${q.optionC} | D: ${q.optionD}", fontSize = 11.sp, color = MitraTextSecondary)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Correct Option: ${q.normalizedCorrectOption()}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MitraGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Close / બંધ કરો",
                    onClick = { viewingQuestionsTest = null },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        )
    }

    if (showConfigDialog) {
        val (currentUrl, currentKey) = sessionManager.getSupabaseConfig()
        SupabaseConfigDialog(
            initialUrl = currentUrl,
            initialKey = currentKey,
            repository = repository,
            onSave = { newUrl, newKey ->
                sessionManager.saveSupabaseConfig(newUrl, newKey)
                loadAllData()
            },
            onDismiss = { showConfigDialog = false }
        )
    }
}

@Composable
private fun AdminStudentsSection(
    usersList: List<User>,
    repository: TestMitraRepository,
    onStudentAdded: () -> Unit,
    onStudentDeleted: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var userToDelete by remember { mutableStateOf<User?>(null) }
    val scope = rememberCoroutineScope()

    val filteredStudents = remember(usersList, searchQuery) {
        val list = usersList.filter { !it.isTeacherOrAdmin }
        if (searchQuery.isBlank()) list
        else list.filter { it.mobileNumber.contains(searchQuery.trim()) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Row: Count and Add Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "વિદ્યાર્થી સંચાલન",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MitraTextPrimary
                )
                Text(
                    text = "Total Students: ${filteredStudents.size}",
                    fontSize = 12.sp,
                    color = MitraTextSecondary
                )
            }

            MitraPrimaryButton(
                text = "+ Add Student / નવો સ્ટુડન્ટ",
                onClick = { showAddDialog = true },
                icon = Icons.Default.PersonAdd,
                testTag = "open_add_student_dialog_button"
            )
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by Mobile Number / નંબરથી શોધો...") },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = MitraNavyPrimary)
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_student_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MitraNavyPrimary,
                unfocusedBorderColor = MitraBorder,
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White
            )
        )

        // Students List
        if (filteredStudents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.People,
                        contentDescription = null,
                        tint = MitraTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (searchQuery.isBlank()) "કોઈ વિદ્યાર્થી નોંધાયેલ નથી\n(No Students Registered Yet)" else "કોઈ પરિણામ મળ્યું નથી\n(No Students Match Search)",
                        fontSize = 14.sp,
                        color = MitraTextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("students_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredStudents, key = { it.id ?: it.mobileNumber.hashCode().toLong() }) { student ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_item_${student.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MitraGreenLight,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.People,
                                            contentDescription = null,
                                            tint = MitraGreen,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = student.mobileNumber,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraTextPrimary
                                    )
                                    Text(
                                        text = "Role: Student ${if (student.id != null) "• ID #${student.id}" else ""}",
                                        fontSize = 12.sp,
                                        color = MitraTextSecondary
                                    )
                                }
                            }

                            if (student.id != null) {
                                IconButton(
                                    onClick = { userToDelete = student },
                                    modifier = Modifier.testTag("delete_student_button_${student.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Student",
                                        tint = MitraError
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Add New Student
    if (showAddDialog) {
        var mobileInput by remember { mutableStateOf("") }
        var passwordInput by remember { mutableStateOf("") }
        var isPasswordVisible by remember { mutableStateOf(false) }
        var isSaving by remember { mutableStateOf(false) }
        var addError by remember { mutableStateOf<String?>(null) }
        val focusManager = LocalFocusManager.current

        AlertDialog(
            onDismissRequest = { if (!isSaving) showAddDialog = false },
            modifier = Modifier.testTag("add_student_dialog"),
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        tint = MitraNavyPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Add Student / નવો સ્ટુડન્ટ",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                        Text(
                            text = "વિદ્યાર્થીનો મોબાઈલ અને પાસવર્ડ દાખલ કરો",
                            fontSize = 12.sp,
                            color = MitraTextSecondary
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = mobileInput,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() } && input.length <= 10) {
                                mobileInput = input
                                addError = null
                            }
                        },
                        label = { Text("Mobile Number (10 Digits)") },
                        placeholder = { Text("e.g. 9876543210") },
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_student_mobile_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            addError = null
                        },
                        label = { Text("Login Password / પાસવર્ડ") },
                        placeholder = { Text("Enter student password") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = MitraNavyPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle visibility"
                                )
                            }
                        },
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_student_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    if (addError != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MitraErrorLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = addError!!,
                                color = MitraError,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Save Student / સાચવો",
                    onClick = {
                        focusManager.clearFocus()
                        if (mobileInput.length != 10) {
                            addError = "કૃપા કરીને ૧૦ અંકનો મોબાઈલ નંબર દાખલ કરો (Enter valid 10-digit number)"
                            return@MitraPrimaryButton
                        }
                        if (passwordInput.isBlank()) {
                            addError = "કૃપા કરીને પાસવર્ડ દાખલ કરો (Enter password)"
                            return@MitraPrimaryButton
                        }

                        isSaving = true
                        addError = null
                        scope.launch {
                            val res = repository.registerUser(mobileInput, passwordInput, role = "student")
                            isSaving = false
                            if (res is Resource.Success) {
                                showAddDialog = false
                                onStudentAdded()
                            } else if (res is Resource.Error) {
                                addError = res.message
                            }
                        }
                    },
                    isLoading = isSaving,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "save_new_student_button"
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { if (!isSaving) showAddDialog = false },
                    modifier = Modifier.testTag("cancel_add_student_button")
                ) {
                    Text("Cancel / રદ કરો", color = MitraTextSecondary)
                }
            }
        )
    }

    // Modal: Confirm Delete Student
    if (userToDelete != null) {
        val student = userToDelete!!
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            title = { Text("Delete Student? / વિદ્યાર્થી કાઢી નાખવો છે?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to remove student with mobile number ${student.mobileNumber}?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        val sId = student.id
                        userToDelete = null
                        if (sId != null) {
                            scope.launch {
                                repository.deleteUser(sId)
                                onStudentDeleted()
                            }
                        }
                    },
                    modifier = Modifier.testTag("confirm_delete_student_button")
                ) {
                    Text("Delete / કાઢી નાખો", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { userToDelete = null }) {
                    Text("Cancel / રદ કરો")
                }
            }
        )
    }
}

@Composable
private fun AdminTestItemCard(
    test: TestItem,
    onViewQuestions: () -> Unit,
    onToggleActive: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_test_card_${test.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.testName,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Duration: ${test.duration} minutes",
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MitraGreenLight
                ) {
                    Text(
                        text = "ID #${test.id}",
                        color = MitraGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons in responsive row with ample spacing & no overlap
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MitraOutlinedButton(
                    text = "View Questions",
                    onClick = onViewQuestions,
                    icon = Icons.Default.FormatListNumbered,
                    modifier = Modifier.weight(1f),
                    height = 44.dp,
                    testTag = "view_questions_button_${test.id}"
                )

                MitraOutlinedButton(
                    text = if (test.isActive) "Deactivate" else "Activate",
                    onClick = onToggleActive,
                    icon = if (test.isActive) Icons.Default.Lock else Icons.Default.CheckCircle,
                    borderColor = if (test.isActive) MitraOrangeLight else MitraGreenLight,
                    contentColor = if (test.isActive) MitraOrange else MitraGreen,
                    modifier = Modifier.weight(0.8f),
                    height = 44.dp,
                    testTag = "toggle_test_button_${test.id}"
                )

                MitraOutlinedButton(
                    text = "Delete",
                    onClick = { showDeleteConfirm = true },
                    icon = Icons.Default.Delete,
                    borderColor = MitraErrorLight,
                    contentColor = MitraError,
                    modifier = Modifier.weight(0.7f),
                    height = 44.dp,
                    testTag = "delete_test_button_${test.id}"
                )
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Test? / ટેસ્ટ કાઢી નાખવો છે?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete '${test.testName}'? All associated questions will also be removed.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    modifier = Modifier.testTag("confirm_delete_test_button")
                ) {
                    Text("Delete / કાઢી નાખો", color = MitraError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel / રદ કરો")
                }
            }
        )
    }
}

@Composable
private fun AdminCreateContentSection(
    testsList: List<TestItem>,
    repository: TestMitraRepository,
    onTestCreated: () -> Unit,
    onQuestionAdded: () -> Unit
) {
    var isCreatingTest by remember { mutableStateOf(false) }
    var isAddingQuestion by remember { mutableStateOf(false) }

    // Create Test Form State
    var newTestName by remember { mutableStateOf("") }
    var newTestDuration by remember { mutableStateOf("15") }
    var testErrorMessage by remember { mutableStateOf<String?>(null) }

    // Add Question Form State
    var selectedTestForQuestion by remember { mutableStateOf<TestItem?>(testsList.firstOrNull()) }
    var testDropdownExpanded by remember { mutableStateOf(false) }
    var questionText by remember { mutableStateOf("") }
    var optionA by remember { mutableStateOf("") }
    var optionB by remember { mutableStateOf("") }
    var optionC by remember { mutableStateOf("") }
    var optionD by remember { mutableStateOf("") }
    var correctOption by remember { mutableStateOf("A") }
    var questionErrorMessage by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // FORM 1: CREATE NEW TEST
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("create_test_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = null,
                        tint = MitraNavyPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "1. Create New Test / નવો ટેસ્ટ બનાવો",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary
                    )
                }

                OutlinedTextField(
                    value = newTestName,
                    onValueChange = {
                        newTestName = it
                        testErrorMessage = null
                    },
                    label = { Text("Test Name / ટેસ્ટનું નામ") },
                    placeholder = { Text("e.g. Gujarati Grammar Test 1") },
                    leadingIcon = {
                        Icon(Icons.Default.Title, contentDescription = null, tint = MitraNavyPrimary)
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_test_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MitraNavyPrimary,
                        unfocusedBorderColor = MitraBorder
                    )
                )

                OutlinedTextField(
                    value = newTestDuration,
                    onValueChange = { input ->
                        if (input.all { it.isDigit() } && input.length <= 4) {
                            newTestDuration = input
                            testErrorMessage = null
                        }
                    },
                    label = { Text("Duration in Minutes / સમય (મિનિટ)") },
                    placeholder = { Text("15") },
                    leadingIcon = {
                        Icon(Icons.Default.QueryBuilder, contentDescription = null, tint = MitraNavyPrimary)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_test_duration_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MitraNavyPrimary,
                        unfocusedBorderColor = MitraBorder
                    )
                )

                if (!testErrorMessage.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MitraErrorLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = testErrorMessage!!,
                            color = MitraError,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                MitraPrimaryButton(
                    text = "Save Test / ટેસ્ટ સાચવો",
                    onClick = {
                        focusManager.clearFocus()
                        if (newTestName.isBlank()) {
                            testErrorMessage = "Please enter test name / ટેસ્ટનું નામ દાખલ કરો"
                            return@MitraPrimaryButton
                        }
                        val dur = newTestDuration.toIntOrNull() ?: 15
                        isCreatingTest = true
                        testErrorMessage = null
                        scope.launch {
                            val res = repository.createTest(newTestName, dur)
                            isCreatingTest = false
                            if (res is Resource.Success) {
                                newTestName = ""
                                newTestDuration = "15"
                                onTestCreated()
                            } else if (res is Resource.Error) {
                                testErrorMessage = res.message
                            }
                        }
                    },
                    isLoading = isCreatingTest,
                    icon = Icons.Default.Save,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "save_test_button"
                )
            }
        }

        // FORM 2: ADD QUESTION TO TEST
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("add_question_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = null,
                        tint = MitraGreen,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "2. Add Question to Test / પ્રશ્ન ઉમેરો",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary
                    )
                }

                if (testsList.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MitraOrangeLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Please create a test above before adding questions.",
                            color = MitraOrange,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                } else {
                    // Test Selector Dropdown
                    ExposedDropdownMenuBox(
                        expanded = testDropdownExpanded,
                        onExpandedChange = { testDropdownExpanded = !testDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedTestForQuestion?.testName ?: testsList.first().testName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Test / ટેસ્ટ પસંદ કરો") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = testDropdownExpanded)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("select_test_dropdown"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MitraNavyPrimary,
                                unfocusedBorderColor = MitraBorder
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = testDropdownExpanded,
                            onDismissRequest = { testDropdownExpanded = false }
                        ) {
                            testsList.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text("${t.testName} (${t.duration}m)") },
                                    onClick = {
                                        selectedTestForQuestion = t
                                        testDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Question Text Input
                    OutlinedTextField(
                        value = questionText,
                        onValueChange = {
                            questionText = it
                            questionErrorMessage = null
                        },
                        label = { Text("Question Text / પ્રશ્ન લખાણ") },
                        placeholder = { Text("Enter question in Gujarati or English...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("question_text_input"),
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    // Options A, B, C, D Inputs
                    OutlinedTextField(
                        value = optionA,
                        onValueChange = { optionA = it },
                        label = { Text("Option A / વિકલ્પ A") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("option_a_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    OutlinedTextField(
                        value = optionB,
                        onValueChange = { optionB = it },
                        label = { Text("Option B / વિકલ્પ B") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("option_b_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    OutlinedTextField(
                        value = optionC,
                        onValueChange = { optionC = it },
                        label = { Text("Option C / વિકલ્પ C") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("option_c_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    OutlinedTextField(
                        value = optionD,
                        onValueChange = { optionD = it },
                        label = { Text("Option D / વિકલ્પ D") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("option_d_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MitraNavyPrimary,
                            unfocusedBorderColor = MitraBorder
                        )
                    )

                    // Correct Option Picker
                    Column {
                        Text(
                            text = "Correct Option / સાચો વિકલ્પ:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            listOf("A", "B", "C", "D").forEach { opt ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { correctOption = opt }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    RadioButton(
                                        selected = correctOption == opt,
                                        onClick = { correctOption = opt },
                                        colors = RadioButtonDefaults.colors(selectedColor = MitraGreen)
                                    )
                                    Text(text = opt, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }

                    if (!questionErrorMessage.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MitraErrorLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = questionErrorMessage!!,
                                color = MitraError,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    MitraSuccessButton(
                        text = "Save Question / પ્રશ્ન સાચવો",
                        onClick = {
                            focusManager.clearFocus()
                            val targetTest = selectedTestForQuestion ?: testsList.firstOrNull()
                            if (targetTest == null) {
                                questionErrorMessage = "Please select a test first"
                                return@MitraSuccessButton
                            }
                            if (questionText.isBlank()) {
                                questionErrorMessage = "Please enter question text"
                                return@MitraSuccessButton
                            }
                            if (optionA.isBlank() || optionB.isBlank() || optionC.isBlank() || optionD.isBlank()) {
                                questionErrorMessage = "Please provide all 4 options (A, B, C, D)"
                                return@MitraSuccessButton
                            }

                            isAddingQuestion = true
                            questionErrorMessage = null
                            scope.launch {
                                val res = repository.addQuestion(
                                    testId = targetTest.id ?: 0L,
                                    questionText = questionText,
                                    optionA = optionA,
                                    optionB = optionB,
                                    optionC = optionC,
                                    optionD = optionD,
                                    correctOption = correctOption
                                )
                                isAddingQuestion = false
                                if (res is Resource.Success) {
                                    questionText = ""
                                    optionA = ""
                                    optionB = ""
                                    optionC = ""
                                    optionD = ""
                                    correctOption = "A"
                                    onQuestionAdded()
                                } else if (res is Resource.Error) {
                                    questionErrorMessage = res.message
                                }
                            }
                        },
                        isLoading = isAddingQuestion,
                        icon = Icons.Default.Save,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "save_question_button"
                    )
                }
            }
        }
    }
}
