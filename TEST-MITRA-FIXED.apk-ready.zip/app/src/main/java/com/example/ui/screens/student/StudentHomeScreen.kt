package com.example.ui.screens.student

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SessionManager
import com.example.data.model.TestItem
import com.example.data.model.User
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.components.MitraSuccessButton
import com.example.ui.components.OfflineErrorCard
import com.example.ui.components.SupabaseConfigDialog
import com.example.ui.components.TestMitraTopBar
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraGreenLight
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentHomeScreen(
    user: User,
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    onStartTest: (testId: Long, testName: String, duration: Int) -> Unit,
    onLogout: () -> Unit
) {
    var testsList by remember { mutableStateOf<List<TestItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isNetworkError by remember { mutableStateOf(false) }
    var showConfigDialog by remember { mutableStateOf(false) }
    var completedTestIds by remember { mutableStateOf<Set<Long>>(emptySet()) }

    val scope = rememberCoroutineScope()

    fun logoutAndReleaseDevice() {
        scope.launch {
            user.id?.let { repository.releaseDevice(it) }
            sessionManager.clearSession()
            onLogout()
        }
    }

    fun loadData() {
        isLoading = true
        errorMessage = null
        isNetworkError = false
        scope.launch {
            val testsRes = repository.getTests()
            val resultsRes = user.id?.let { repository.getStudentResults(it) }
            isLoading = false
            when (testsRes) {
                is Resource.Success -> {
                    testsList = testsRes.data.filter { it.isActive }
                }
                is Resource.Error -> {
                    errorMessage = testsRes.message
                    isNetworkError = testsRes.isNetworkError
                }
                else -> {}
            }

            if (resultsRes is Resource.Success) {
                completedTestIds = resultsRes.data.map { it.testId }.toSet()
            }
        }
    }

    LaunchedEffect(user.id) {
        loadData()
        while (true) {
            kotlinx.coroutines.delay(10000)
            val current = user.id?.let { repository.getUserById(it) }
            if (current is Resource.Success) {
                val account = current.data
                if (account == null || !account.isActive || account.deviceId != sessionManager.getDeviceId()) {
                    logoutAndReleaseDevice()
                    break
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TestMitraTopBar(
                title = "TEST MITRA",
                subtitle = "Student Portal • ${user.mobileNumber}",
                userRole = "Student",
                onRefresh = { loadData() },
                onOpenSettings = { showConfigDialog = true },
                onLogout = {
                    logoutAndReleaseDevice()
                }
            )
        },
        modifier = Modifier
            .fillMaxSize()
            .testTag("student_home_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MitraBgLight)
        ) {
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color = MitraNavyPrimary,
                                strokeWidth = 3.5.dp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Loading tests from Supabase...\nટેસ્ટ લોડ થઈ રહ્યા છે...",
                                color = MitraTextSecondary,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                errorMessage != null -> {
                    OfflineErrorCard(
                        errorMessage = errorMessage,
                        onRetry = { loadData() },
                        onOpenSettings = { showConfigDialog = true }
                    )
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Section Header Banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ઉપલબ્ધ એમસીક્યુ ટેસ્ટ",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MitraTextPrimary
                                )
                                Text(
                                    text = "Available Tests (${testsList.size})",
                                    fontSize = 12.sp,
                                    color = MitraTextSecondary
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MitraGreenLight
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = MitraGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${testsList.size} Active Tests",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraGreen
                                    )
                                }
                            }
                        }

                        // Tests List
                        if (testsList.isEmpty()) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = MitraTextMuted,
                                        modifier = Modifier.size(52.dp)
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = "હાલ કોઈ ટેસ્ટ ઉપલબ્ધ નથી",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MitraTextPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "શિક્ષક દ્વારા નવો ટેસ્ટ ઉમેરાય પછી અહીં દેખાશે.",
                                        fontSize = 13.sp,
                                        color = MitraTextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    MitraPrimaryButton(
                                        text = "Refresh / રિફ્રેશ કરો",
                                        onClick = { loadData() }
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("tests_list"),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(testsList, key = { it.id ?: 0L }) { test ->
                                    StudentTestCard(
                                        test = test,
                                        completed = completedTestIds.contains(test.id),
                                        onStartTest = {
                                            onStartTest(test.id ?: 0L, test.testName, test.duration)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showConfigDialog) {
        val (currentUrl, currentKey) = sessionManager.getSupabaseConfig()
        SupabaseConfigDialog(
            initialUrl = currentUrl,
            initialKey = currentKey,
            repository = repository,
            onSave = { newUrl, newKey ->
                sessionManager.saveSupabaseConfig(newUrl, newKey)
                loadData()
            },
            onDismiss = { showConfigDialog = false }
        )
    }
}

@Composable
private fun StudentTestCard(
    test: TestItem,
    completed: Boolean,
    onStartTest: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("test_card_${test.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.testName,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MitraTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "MCQ Online Examination / એમસીક્યુ પરીક્ષા",
                        fontSize = 12.sp,
                        color = MitraTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MitraGreenLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.QueryBuilder,
                            contentDescription = null,
                            tint = MitraGreen,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${test.duration} min",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraGreen
                        )
                    }
                }
            }

            if (completed) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MitraGreenLight
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = MitraGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "Test Completed / ટેસ્ટ આપી દીધી",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Start Test Button (Full Width, Large Touch Area, No Overlap)
            MitraSuccessButton(
                text = "Start Test / ટેસ્ટ આપો",
                onClick = onStartTest,
                icon = Icons.Default.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
                height = 48.dp,
                testTag = "start_test_button_${test.id}"
            )
        }
    }
}
