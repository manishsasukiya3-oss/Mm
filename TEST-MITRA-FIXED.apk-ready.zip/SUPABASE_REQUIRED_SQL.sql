-- TEST MITRA: required database change for Test Active/Deactive
-- No existing data is deleted.

ALTER TABLE public.tests
ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

UPDATE public.tests
SET is_active = true
WHERE is_active IS NULL;
